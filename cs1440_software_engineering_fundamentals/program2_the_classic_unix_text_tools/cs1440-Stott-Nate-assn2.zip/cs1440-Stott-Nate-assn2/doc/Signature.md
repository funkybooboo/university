| Date         | Time Spent | Events
|--------------|------------|--------------------
| September 19  | 0.25 hour | cloned repo onto my computer
| September 20  | 2 hours | completed the shell lessons, read the .md files in the instructions directory, and complete phase 0 in the Plan
| September 21 | 1 hour | looked over the .md files in the examples directory under the instructions directory and read the starter code and work on phase 1 in the Plan
| September 22 | .5 hour | work on phase 1 in the Plan
| September 23 | 1 hour | work on phase 1 in the Plan and in class write the cat tool and the tac tool and create a Helper.py file so I can write helper messages later on.
| September 24 | 0.25 hour | work on phase 1 in the Plan
| September 25 | 1.75 hour | finished phase 1 and work on phase 2 in the Plan
| September 26 | 1.5 hour | finish phase 2 and start working on phase 3 in the Plan
| September 27 | 3 hour | finish phase 3 in the plan and started working on the phase 4
| September 28 | 2 hour | finished the assignment
| TOTAL | 12.25 hours
