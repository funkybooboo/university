| Error Code | Meaning 
|--------------|------------
| 0 | Program exited without any issues
| 1 | Program found that it didnt have the correct format of arguments passed in
| 2 | Program was not used properly 
