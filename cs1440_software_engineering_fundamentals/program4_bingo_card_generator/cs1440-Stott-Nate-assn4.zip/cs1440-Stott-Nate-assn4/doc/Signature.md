| Date        | Time Spent | Events  	         	  
|-------------|------------|--------------------  	         	  
| October 17 | .5 hour | Set up repository and read instructions
| October 18 | .5 hour | Read instructions
| October 20 | 2.5 hour | Read instructions and provided code. Complete phase 0 and 1 in the Plan. worked on UML diagram
| October 21 | 2.5 hour | Write the user manual, and Personal review of the C++ teams work. started to work on phase 2 and worked ont he UML diagram.
| October 22 | 1 hour | work on phase 2 
| October 23 | 1 hour | work on phase 2
| October 24 | 2 hour | finish phase 2
| October 25 | 3 hour | finish phase 3 and 4
| October 26 | 2 hour | finish phase 5 and 6 and fixed unittests
| Total | 15 hours
