| Date        | Time Spent | Events
|-------------|------------|--------------------
| September 6 | 1 hours    | Worked on the lessons in the lsn directory
| September 7 | .5 hours   | Finished the lessons in the lsn directory
| September 8 | 2 hours    | Read about what DuckieDecryper and DuckieCtyper is and did Phase 0 in the software development plan
| September 9 | 1 hours    | Did phase 1 in the software development plan
| September 10 | 1.5 hours  | worked on phase 2 in the software development plan 
| September 12 | 2 hours    | finished up phase 2 and did phase 3 in the software development plan
| September 13 | 2 hours    | Did phase 4, 5, and 6
| september 14 /.5 hours | Made sure everything looks good
| TOTAL       | 10 hours   | Total time of all work done
