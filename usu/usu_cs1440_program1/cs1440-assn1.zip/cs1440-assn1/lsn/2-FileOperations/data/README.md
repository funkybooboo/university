# `prac/openClose/data` Directory
This directory is for ease of access to some files for the open and closing
files exercises. Feel free to add files to this directory for experimentation
purposes. Please do not modify the contents or names of the existing files, the
tests rely on the current structure.
