To view plan use 
http://"Replace with server IP address":8000/gold/plan/

Conversion factors where found using the Google unit converter and selecting 'mass'.
https://support.google.com/websearch/answer/3284611?hl=en#unitconverter
