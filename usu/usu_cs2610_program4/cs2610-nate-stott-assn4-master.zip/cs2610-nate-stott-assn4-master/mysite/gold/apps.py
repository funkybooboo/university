from django.apps import AppConfig


class GoldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gold'
