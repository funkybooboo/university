# Software Development Plan

## Phase 0: Requirements Specification *(10%)*

#### How the user interacts with the program
The program will have a terminal interface and will take few keystrokes to get the desired output. The output should be easy to read and have all fields being calculated correctly and be in the right format the customer requested. 

#### Possible input and outputs
Here is an example of input the program can take:
```
python src/bigData.py data/USA_full
```
There are 3 parts to this interface that I will go over.
1. A user needs to type python or python3 depending on the find of python interpreter is on the computer. This is because the python interpreter will run the code in the specified filepath given in the first argument.
2. A user needs to put in the relative filepath to the program that they would like to run. For the example above we are in the cs1440-Stott-Nate-assn3 directory and the relative filepath from there is "src/bigData.py".
3. A user needs to put in the relative filepath to the directory they would like to be outputted. The directory needs to have an "area-titles.csv" file in order for the program to run. The "area-titles.csv" file needs to contain what "area_fips" and "area_title". The directory also needs the "2021.annual.singlefile.csv" file for that specific region which has all the hard data the program needs to add up the totals. The "2021.annual.singlefile.csv" file must have at least 6 rows and then corresponding columns of data with each row: area_fips, industry_code, own_code, total_annual_wages, annual_avg_emplvl, and annual_avg_estabs.

Here is an example of what input the user can enter and what the output should look like.

input:
```
python src/bigData.py data/DC_complete
```
output:
```
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       2

Total annual wages                   $81,399,706,788
Area with maximum annual wages       District of Columbia
Maximum reported wage                $81,389,813,093

Total number of establishments       44,401
Area with most establishments        District of Columbia
Maximum # of establishments          44,385

Total annual employment level        725,825
Area with maximum employment         District of Columbia
Maximum reported employment level    725,756


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       1

Total annual wages                   $752,965,558
Area with maximum annual wages       District of Columbia
Maximum reported wage                $752,965,558

Total number of establishments       272
Area with most establishments        District of Columbia
Maximum # of establishments          272

Total annual employment level        1,434
Area with maximum employment         District of Columbia
Maximum reported employment level    1,434
```

#### Things I know and what I'm expecting to be a challenge
I did the last project that DuckieCorp management gave me, and I did well on it, so I know how to play around with text in python, so I should be able to use past skills learned on this new project. But with this project there is a lot of data that I need to go through so I need to be careful to not load to much into memory or else my program might crash.


## Phase 1: System Analysis *(10%)*

#### Input and Output

##### Valid input and program set up
If the user has set up the program correctly by having proper directory's each with the "area-titles.csv" file that contains what data the user what's to be calculated and the "2021.annual.singlefile.csv" file is in the USU-full directory, then the program can run correctly given the user interacts with the program's interface correctly.

In the given data under the data directory there are many subdirectories. Don't be overwhelmed by how many directories there are because we can group all the subdirectories into 7 parts. The first part of the directory name is how we can tell they are a part of the same group. For example lets look at the DC group:

There are four files in this group.
1. DC_all_industries
    * If a user wants data about all industries in the DC area then they will enter the filepath to this directory the bottom half of the report will have 0's.
2. DC_complete
    * If a user wants data about the entire economy in the DC area then they will enter the filepath to this directory.
3. DC_reversed
    * This directory holds the same information that DC_complete has but in reverse order. The output will be the same as DC_complete.
4. DC_software_industry
    * If a user wants data about only the software industry in the DC area then they will enter the filepath to this directory the top half of the report will have 0's.

Groups in the given data under the data directory are:
1. The DC group with DC_ being the start of each subdirectory in the group. This group holds data about the District of Columbia.
2. The HI group with HI_ being the start of each subdirectory in the group. This group holds data about the state of Hawaii.
3. The ME group with ME_ being the start of each subdirectory in the group. This group holds data about the state of Maine.
4. The OH group with OH_ being the start of each subdirectory in the group. This group holds data about the state of Ohio.
5. The UT group with UT_ being the start of each subdirectory in the group. This group holds data about the state of Utah.
6. The WV group with WV_ being the start of each subdirectory in the group. This group holds data about the state of West Virgina.
7. The USA group with USA_ being the start of the single subdirectory in the group. This group holds data about the whole United States of America.

Here are some examples of correct input to the program's interface using the HI group:

---------

input:
```
python src/bigData.py data/HI_all_industries
```
output:
```
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       0

Total annual wages                   $0
Area with maximum annual wages       
Maximum reported wage                $0

Total number of establishments       0
Area with most establishments        
Maximum # of establishments          0

Total annual employment level        0
Area with maximum employment         
Maximum reported employment level    0
```

---------

input:
```
python src/bigData.py data/HI_complete
```
output:
```
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $59,086,469
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $27,679,356

Total number of establishments       229
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          121

Total annual employment level        291
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    150
```

---------

input:
```
python src/bigData.py data/HI_reversed
```
output:
```
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $59,086,469
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $27,679,356

Total number of establishments       229
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          121

Total annual employment level        291
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    150
```

---------

input:
```
python src/bigData.py data/HI_software_industry
```
output:
```
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       0

Total annual wages                   $0
Area with maximum annual wages       
Maximum reported wage                $0

Total number of establishments       0
Area with most establishments        
Maximum # of establishments          0

Total annual employment level        0
Area with maximum employment         
Maximum reported employment level    0


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $59,086,469
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $27,679,356

Total number of establishments       229
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          121

Total annual employment level        291
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    150
```

---------

##### Invalid input or program set up
1. If the user puts in an invalid filepath then the program will crash.
2. If the user doesn't put a filepath then a message saying "user needs to put in a filepath" will be printed.
3. If the user puts more than one filepath than the program will print a message saying "please only enter one filepath" will be printed.
4. If there is no "area-titles.csv" file in the given directory then the program will crash.
5. If an "area-titles.csv" file is found but doesn't have the "area_fips" and "area_title" rows then the program will crash.
6. If the "2021.annual.singlefile.csv" file isnt in the directory and can't be found then the program will crash.
7. If the "2021.annual.singlefile.csv" file is found but doesn't have "area_fips", "industry_code", "own_code", "total_annual_wages", "annual_avg_emplvl", and "annual_avg_estabs" rows then the program will crash.

#### Key functions the program needs

* def usage(message, errorCode):
    * Given a message and an error code the usage function will print out what went wrong with some pointers about how to use the program correctly.
* def getDataFromAS(userDirectory):
    * returns a dictionary with the values from the "2021.annual.singlefile.csv" file with the key being row data and the value being the value found in the "2021.annual.singlefile.csv" file.
* def getFipsTooNamesDictionary(userDirectory):
    * returns a dictionary with FIPS codes mapped to the county names.
* def getFileObjects(userDictionary):
  * return a list of two file objects the first the "area-titles.csv" file the second the "2021.annual.singlefile.csv" file.
* def getDicOfRowsNamesToIndexes(theFirstLineInASFile):
  * return dictionary of wanted names to indexes


## Phase 2: Design *(30%)*

* bigData.py
  * def usage(message, errorCode):
    * print the message that the user gave
    * then print a message detailing how to use the program better so a crash doesn't happen again.
    * end the program with whatever errorCode was passed into the function.
  * def getDataFromAS(ASFileObj):
    * make a counter and count how many lines the loop goes over and at the end of the loop put the counter number into a dictionary with "num_areas" being the key and the counter number being the value.
    * read line by line in a loop but skip the first line.
    * split the line up by commas and save each string into a list.
    * look up what index the "area_fips" is found in the fipsToIndexDic dictionary then look at that index in the list of strings. If the last 3 parts of the string are all 0's or if the first two are US or the first part is C or the first two is CS or first is M or first three are CMS then move onto the next line.
    * now we know we have a valid fips code so we can look up what position the "industry_code" is and then check that position in the list of strings. Then we can check if that "industry_code" is equal to 10 or 5112 depending on if the user wants software industry data or industry data. if they are not move onto the next line.
    * then we can check what the "own_code" index is in the list and then check that string. If its equal to 0 or 5 depending on if the user wants software industry data or industry data. if they are not move onto the next line.
    * now we know we have a valid line with data that matters in our report so we can check the "total_annual_wages", "annual_avg_emplvl", and "annual_avg_estabs" indexes and then look them up in the list of strings.
    * for "total_annual_wages" turn this from a string to a integer and then add it to a running total.
    * keep track of what "total_annual_wages" is the highest and from what fips code
    * for "annual_avg_emplvl" turn this from a string to a integer and then add it to a running total.
    * keep track of what "annual_avg_emplvl" is the highest and from what fips code
    * for "annual_avg_estabs" turn this from a string to a integer and then add it to a running total.
    * keep track of what "annual_avg_estabs" is the highest and from what fips code
    * return dictionary of found values
  * def getDicOfRowsNamesToIndexes(theFirstLineInASFile):
    * split line by commas and save strings into list
    * iterate over list until the "area_fips" is found and save the name as the key in a dictionary and the index of the name as the value.
    * Do this for "industry_code", "own_code", "total_annual_wages", "annual_avg_emplvl", and "annual_avg_estabs"
  * def getFipsTooNames(ATFileObj):
    * read line by line in a loop.
    * split the line up by commas and save each string into a list.
    * get the first item in the list and make that the key and the second the value in a dictionary.
    * go through all the lines
    * close the file object
    * return the dictionary
  * def getFileObjects(userDictionary):
    * open the userDictionary path + "/area-titles.csv" and save that into a file object 
    * open the userDictionary path + "/2021.annual.singlefile.csv" and save that into a file object 
    * return both in a list

In the face of good input the program will calculate the right totals for the given directory.

In the face of bad input the program will either crash with the default python message or there will be a custom message that will explain what went wrong and how to prevent the program from crashing in the future.


## Phase 3: Implementation *(15%)*

I think everything went swimmingly. I read the instructions thoroughly several times, and I read through the US bureau of labor statistics pages online also I talked to Eirk on zoom and he helped me get onto a better track and understanding. Doing all that really helped see what the program is supposed to be doing. This made it easy to make a design and then build it. My code is more or less what I was imagining and it more or less follows my pseudocode line by line. Getting everything I needed into one function really helped to get all the needed values to the report.

## Phase 4: Testing & Debugging *(30%)*

#### what I needed to fix in my code

There was three small things I needed to fix in my code but once they where fixed everything was working great!
1. I needed to strip away extra quote marks in the strings I was comparing with.
2. I needed to only split on one comma and not all of them because there are some county names with a comma in them and I was getting 3 strings in a list when I needed two.
3. I needed to compare with the maximum value found so far with the current value not with the last value that was seen on the last line.

#### testing good input

input:
```
python3 src/bigData.py data/DC_all_industries 
```
output:
```
Reading the databases...
Done in 0.005 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       2

Total annual wages                   $81,399,706,788
Area with maximum annual wages       District of Columbia
Maximum reported wage                $81,389,813,093

Total number of establishments       44,401
Area with most establishments        District of Columbia
Maximum # of establishments          44,385

Total annual employment level        725,825
Area with maximum employment         District of Columbia
Maximum reported employment level    725,756


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       0

Total annual wages                   $0
Area with maximum annual wages       
Maximum reported wage                $0

Total number of establishments       0
Area with most establishments        
Maximum # of establishments          0

Total annual employment level        0
Area with maximum employment         
Maximum reported employment level    0
```

input:
```
python3 src/bigData.py data/DC_complete   
```
output:
```
Reading the databases...
Done in 0.015 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       2

Total annual wages                   $81,399,706,788
Area with maximum annual wages       District of Columbia
Maximum reported wage                $81,389,813,093

Total number of establishments       44,401
Area with most establishments        District of Columbia
Maximum # of establishments          44,385

Total annual employment level        725,825
Area with maximum employment         District of Columbia
Maximum reported employment level    725,756


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       1

Total annual wages                   $752,965,558
Area with maximum annual wages       District of Columbia
Maximum reported wage                $752,965,558

Total number of establishments       272
Area with most establishments        District of Columbia
Maximum # of establishments          272

Total annual employment level        1,434
Area with maximum employment         District of Columbia
Maximum reported employment level    1,434
```

input:
```
python3 src/bigData.py data/DC_reversed 
```
output:
```
Reading the databases...
Done in 0.012 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       2

Total annual wages                   $81,399,706,788
Area with maximum annual wages       District of Columbia
Maximum reported wage                $81,389,813,093

Total number of establishments       44,401
Area with most establishments        District of Columbia
Maximum # of establishments          44,385

Total annual employment level        725,825
Area with maximum employment         District of Columbia
Maximum reported employment level    725,756


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       1

Total annual wages                   $752,965,558
Area with maximum annual wages       District of Columbia
Maximum reported wage                $752,965,558

Total number of establishments       272
Area with most establishments        District of Columbia
Maximum # of establishments          272

Total annual employment level        1,434
Area with maximum employment         District of Columbia
Maximum reported employment level    1,434
```

input:
```
python3 src/bigData.py data/DC_software_industry
```
output:
```
Reading the databases...
Done in 0.005 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       0

Total annual wages                   $0
Area with maximum annual wages       
Maximum reported wage                $0

Total number of establishments       0
Area with most establishments        
Maximum # of establishments          0

Total annual employment level        0
Area with maximum employment         
Maximum reported employment level    0


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       1

Total annual wages                   $752,965,558
Area with maximum annual wages       District of Columbia
Maximum reported wage                $752,965,558

Total number of establishments       272
Area with most establishments        District of Columbia
Maximum # of establishments          272

Total annual employment level        1,434
Area with maximum employment         District of Columbia
Maximum reported employment level    1,434
```

input:
```
python3 src/bigData.py data/HI_all_industries
```
output:
```
Reading the databases...
Done in 0.005 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       0

Total annual wages                   $0
Area with maximum annual wages       
Maximum reported wage                $0

Total number of establishments       0
Area with most establishments        
Maximum # of establishments          0

Total annual employment level        0
Area with maximum employment         
Maximum reported employment level    0
```

input:
```
python3 src/bigData.py data/HI_complete
```
output:
```
Reading the databases...
Done in 0.022 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $59,086,469
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $27,679,356

Total number of establishments       229
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          121

Total annual employment level        291
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    150
```

input:
```
python3 src/bigData.py data/HI_reversed
```
output:
```
Reading the databases...
Done in 0.023 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $35,075,731,287
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $26,109,106,430

Total number of establishments       48,028
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          28,118

Total annual employment level        588,087
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    419,146


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       5

Total annual wages                   $59,086,469
Area with maximum annual wages       Honolulu County, Hawaii
Maximum reported wage                $27,679,356

Total number of establishments       229
Area with most establishments        Honolulu County, Hawaii
Maximum # of establishments          121

Total annual employment level        291
Area with maximum employment         Honolulu County, Hawaii
Maximum reported employment level    150
```

input:
```
python3 src/bigData.py data/ME_complete
```
output:
```
Reading the databases...
Done in 0.045 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       17

Total annual wages                   $33,343,143,368
Area with maximum annual wages       Cumberland County, Maine
Maximum reported wage                $11,542,998,173

Total number of establishments       58,118
Area with most establishments        Cumberland County, Maine
Maximum # of establishments          15,769

Total annual employment level        610,109
Area with maximum employment         Cumberland County, Maine
Maximum reported employment level    181,471


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       14

Total annual wages                   $74,366,420
Area with maximum annual wages       Cumberland County, Maine
Maximum reported wage                $32,670,542

Total number of establishments       267
Area with most establishments        Cumberland County, Maine
Maximum # of establishments          105

Total annual employment level        498
Area with maximum employment         Cumberland County, Maine
Maximum reported employment level    249
```

input:
```
python3 src/bigData.py data/OH_complete
```
output:
```
Reading the databases...
Done in 0.169 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       89

Total annual wages                   $306,154,392,599
Area with maximum annual wages       Franklin County, Ohio
Maximum reported wage                $48,628,531,917

Total number of establishments       315,117
Area with most establishments        Cuyahoga County, Ohio
Maximum # of establishments          37,749

Total annual employment level        5,246,892
Area with maximum employment         Franklin County, Ohio
Maximum reported employment level    743,438


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       71

Total annual wages                   $1,051,651,072
Area with maximum annual wages       Franklin County, Ohio
Maximum reported wage                $204,876,493

Total number of establishments       1,870
Area with most establishments        Unknown Or Undefined, Ohio
Maximum # of establishments          432

Total annual employment level        9,074
Area with maximum employment         Cuyahoga County, Ohio
Maximum reported employment level    1,603
```

input:
```
python3 src/bigData.py data/USA_full
```
output:
```
Reading the databases...
Done in 4.802 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       3,274

Total annual wages                   $9,749,457,535,475
Area with maximum annual wages       New York County, New York
Maximum reported wage                $349,820,933,687

Total number of establishments       10,960,881
Area with most establishments        Los Angeles County, California
Maximum # of establishments          525,496

Total annual employment level        144,691,578
Area with maximum employment         Los Angeles County, California
Maximum reported employment level    4,252,857


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       1,627

Total annual wages                   $111,505,515,321
Area with maximum annual wages       King County, Washington
Maximum reported wage                $24,259,942,206

Total number of establishments       54,994
Area with most establishments        New York County, New York
Maximum # of establishments          1,636

Total annual employment level        535,426
Area with maximum employment         King County, Washington
Maximum reported employment level    74,792
```

input:
```
python3 src/bigData.py data/UT_complete
```
output:
```
Reading the databases...
Done in 0.056 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       29

Total annual wages                   $91,599,721,263
Area with maximum annual wages       Salt Lake County, Utah
Maximum reported wage                $48,901,839,711

Total number of establishments       121,475
Area with most establishments        Salt Lake County, Utah
Maximum # of establishments          55,945

Total annual employment level        1,583,750
Area with maximum employment         Salt Lake County, Utah
Maximum reported employment level    737,675


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       21

Total annual wages                   $2,222,326,372
Area with maximum annual wages       Utah County, Utah
Maximum reported wage                $1,159,664,504

Total number of establishments       1,550
Area with most establishments        Salt Lake County, Utah
Maximum # of establishments          1,035

Total annual employment level        14,861
Area with maximum employment         Utah County, Utah
Maximum reported employment level    7,226
```

input:
```
python3 src/bigData.py data/WV_complete
```
output:
```
Reading the databases...
Done in 0.072 seconds!
[============]
[Final Report]
[============]

Statistics over all industries in 2021:
=========================================================
Number of FIPS areas in report       56

Total annual wages                   $33,217,958,335
Area with maximum annual wages       Kanawha County, West Virginia
Maximum reported wage                $4,934,493,735

Total number of establishments       53,546
Area with most establishments        Unknown Or Undefined, West Virginia
Maximum # of establishments          8,370

Total annual employment level        657,805
Area with maximum employment         Kanawha County, West Virginia
Maximum reported employment level    91,450


Statistics over the software publishing industry in 2021:
=========================================================
Number of FIPS areas in report       15

Total annual wages                   $8,889,753
Area with maximum annual wages       Unknown Or Undefined, West Virginia
Maximum reported wage                $7,976,964

Total number of establishments       104
Area with most establishments        Unknown Or Undefined, West Virginia
Maximum # of establishments          74

Total annual employment level        85
Area with maximum employment         Unknown Or Undefined, West Virginia
Maximum reported employment level    65
```

I figured after testing that amount I was good.

#### testing bad input

input:
```
python3 src/bigData.py data/wefa
```
output:
```
Reading the databases...
Traceback (most recent call last):
  File "/Users/nathanstott/CS1440/cs1440-Stott-Nate-assn3/src/bigData.py", line 222, in <module>
    ATFileObj, ASFileObj = getFileObjects(sys.argv[1])
  File "/Users/nathanstott/CS1440/cs1440-Stott-Nate-assn3/src/bigData.py", line 205, in getFileObjects
    ATFileObj = open(userDictionary + "/area-titles.csv")
FileNotFoundError: [Errno 2] No such file or directory: 'data/wefa/area-titles.csv'
```
Reason for fail:
The user put in an invalid directory so the program crashed as the instructions said.

input:
```
python3 src/bigData.py
```
output:
```

not enough arguments
Usage: src/bigData.py DATA_DIRECTORY
```
Reason for fail: The user didnt put in enough arguments so the program printed out a usage message as the instructions said.


## Phase 5: Deployment *(5%)*

*   *Important:* complete **Phase 6** first!
    *   (I know it's backwards, just go with it)
*   **YOU DON'T NEED TO WRITE ANYTHING IN THIS PHASE**
    *   Just follow this checklist
*   **Push** your final commit to GitLab
*   **Verify** that your final commit was received by *browsing* to its project page on GitLab
    *   Ensure the project's *URL is correct*
    *   Review that all required files are present *in the correct location*
    *   Check that unwanted files *have not* been committed
    *   Add *final touches* to your documentation, including the Sprint Signature and this Plan
*   **Validate** that your submission is complete and correct by *cloning* it to a new location on your computer and re-running it
	*	Run your program from the *command line* so you can see how it will behave when your grader runs it
        *   **Testing in PyCharm is not good enough!**
    *   Re-run your *test cases* to avoid nasty surprises
    

## Phase 6: Maintenance

* Write *brief and honest* answers to these questions: *(Note: do this before you complete **Phase 5: Deployment**)*
    * What parts of your program are *sloppily written* and *hard to understand*?
      * I would say none. I had a good starting design
          * Are there parts of your program which you *aren't quite sure* how/why they work?
            * No I know how they all work and why
          * If a bug is reported in a few months, *how long would it take you to find the cause*?
            * Probably like 20 mins there really isnt that much code
    * Will your documentation make sense to...
        * ...anybody *besides yourself*
          * Yes its very detailed 
        * ...*yourself* in six month's time?
          * Yes its also not every complicated
    * How easy will it be to *add a new feature* to this program in a year?
      * Pretty easy I broke my program up a lot into functions so it should be easy to add what I want with my modularity design
    * Will your program *continue to work* after upgrading...
          * ...your computer's *hardware*?
            * Yes an long as you have the python interpreter on your computer
          * ...the *operating system*?
            * Yes as long as you have the python interpreter on your computer
          * ...to the *next version* of Python?
            * Yes I dont use anything fancy or basic that will be taken away in the next version of python
* Fill out the *Assignment Reflection* survey on Canvas
  * Ok
  