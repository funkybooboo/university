| Date         | Time Spent | Events
|--------------|------------|--------------------
| October 3 | 1.5 hour | finished both shell tutor lessons and pushed the certificate to gitlab
| October 4 | 2 hour | finished phase 0 in the Plan
| October 5 | 2 hour | finished phase 1 in the Plan
| October 6 | 2 hour | get the 2021.annual.singlefile.csv in all subdirectories under the data directory. Worked on phase 2 in the plan. Fixed some things in phase 0 and 1 because I have a better understanding of the program.
| October 7 | 1.5 hour | worked on phase 2 in the Plan and fixed some issues in phase 1 and 0.
| October 8 | 0.5 hour | finished phase 2 in the Plan and updated my repo based off of a message that Ditton sent out on canvas.
| October 10 | 4 hour | finished phase 3 in the Plan
| October 11 | 2 hour | finished phase 4,5,6 in the Plan
| TOTAL | 15.5
